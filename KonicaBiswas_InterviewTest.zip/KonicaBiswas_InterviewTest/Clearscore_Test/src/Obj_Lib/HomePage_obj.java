package Obj_Lib;

import org.openqa.selenium.By;

public class HomePage_obj {

public static By by = null;
	
	public static By signup_button()
	{
		by = By.xpath("//a[@class='navLink--2aGgl button--IIPPe']");
		return by;
	}
	
	public static By cookie_notif()
	{
		by = By.xpath("//p[@class='cookieInformation--2m9KY']");
		return by;
	}
	
	public static By cookie_accept()
	{
		by = By.xpath("//button[@class='button---dYCq']");
		return by;
	}
}
