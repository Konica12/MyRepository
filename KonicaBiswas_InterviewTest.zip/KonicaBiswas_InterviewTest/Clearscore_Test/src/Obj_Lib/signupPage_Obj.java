package Obj_Lib;

import org.openqa.selenium.By;

public class signupPage_Obj {

	public static By by = null;
	
	public static By emailid_textbox()
	{
		by = By.xpath("//input[@id='signupform_email_input']");
		return by;
	}
	
	public static By country_dropdwn()
	{
		by = By.xpath("//select[@id='signupform_region_input']");
		return by;
	}
	
	public static By getstarted_button()
	{
		by = By.xpath("//button[@class='base--2Z7Kb button--26LBC overlay--2AUiP']");
		return by;
	}
	
	
}
