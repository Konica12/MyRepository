package clearscore;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeTest;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

import org.testng.Assert;

public class Init {
	
  public static WebDriver driver = null;
  public static String app_url = "https://www.clearscore.com",browser = null;
  static Logger app_logs= Logger.getLogger(Init.class);
  
  
  @BeforeSuite
  public void beforeSuite() {
	  PropertyConfigurator.configure("src/resources/log4j.properties");
	  app_logs.info("Test Suite Started ::");
		app_logs.info("========================================");

  }

   @BeforeTest
  @Parameters({"browser"})
  public void beforeTest(String testngbrowser) throws Exception {
	  try
  	{
  	  browser = testngbrowser;
  	  
  	  if (browser.equalsIgnoreCase("firefox"))
  	  {	  
  		  System.setProperty("webdriver.gecko.driver","Executables\\GeckoDriver\\geckodriver.exe");
  	  
  	       driver = new FirefoxDriver();
  	       app_logs.info(" browser is initialized for ->"+ browser);
  	       
  	  }  
  	  else if(browser.equalsIgnoreCase("chrome")){
  		  System.setProperty("webdriver.chrome.driver","Executables\\ChromeDriver\\chromedriver.exe");

			driver =  new ChromeDriver();
			
			System.out.println("Browser initialised");
			app_logs.info("browser is initialized for ->"+ browser);
  	  }
  	  
  	  else if(browser.equalsIgnoreCase("IE")){
  		  System.setProperty("webdriver.ie.driver","Executables\\IEDriverServer\\IEDriverServer.exe");

			driver =  new InternetExplorerDriver();
			System.out.println("Browser initialised");
			app_logs.info("browser is initialized for ->"+ browser);
  	  }
  	  
  	  //driver.get(app_url);
			
  		
  	}
  
    catch(Exception e)
    {
  	Assert.fail();
    }
 }
  
   @Test
  	public void launchAppURL() throws Exception
  	
  	{
  		try {
  			driver.get(app_url);
  			driver.manage().window().maximize();
  		}
  		catch(Exception e)
  		{
  			e.printStackTrace();
  			app_logs.info("Please check the URL again.URL might be incorrect");
  			Assert.fail("URL is incorrect");
  		}
  	  		
  	}

  @AfterSuite
  public void afterSuite() {
	  app_logs.info("========================================");
		app_logs.info("Test Suite Completed ::");
		app_logs.info("========================================");
  }

}
