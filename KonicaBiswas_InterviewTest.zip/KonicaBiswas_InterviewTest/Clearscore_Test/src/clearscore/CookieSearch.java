package clearscore;

import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import Function_Lib.ActionBot;
import Obj_Lib.HomePage_obj;


public class CookieSearch extends Init{
	
	static Logger app_logs= Logger.getLogger(CookieSearch.class);
	public static boolean isDisplayed = false, isEnabled=false;
  @Test
  public static void Fn_Cookie() throws Exception{
	  try
	  {  
		  isDisplayed = driver.findElement(HomePage_obj.cookie_notif()).isDisplayed();
		  if(isDisplayed)
		  {
			  app_logs.info("We Use cookies - Notifictaion is Present");
			  isEnabled = ActionBot.Fn_Enabled(HomePage_obj.cookie_accept());
			    if(isEnabled)
			    {
			    	ActionBot.Fn_click(HomePage_obj.cookie_accept());
			    	app_logs.info("Cookie Notification is Accepted");
			    }
		   }
		 }
	  
	  catch(Exception e)
	  {
		  e.printStackTrace();
		  Assert.fail();
	  }
	  
	 
  }
  
  @Test(expectedExceptions  = {NoSuchElementException.class}) //To check if cookie notification is present.
  public static void Fn_cookie_Check() { 
	  isDisplayed = driver.findElement(HomePage_obj.cookie_notif()).isDisplayed();
	  if(!isDisplayed)
		  Assert.assertEquals(false, "Cookie Notification Not Present after Accepting cookies");
	  else
		  Assert.fail("Element is still present after Accepting cookies");
	  }
  
    
}
