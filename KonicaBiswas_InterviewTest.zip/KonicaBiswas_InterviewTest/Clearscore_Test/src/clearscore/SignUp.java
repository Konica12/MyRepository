package clearscore;

import java.util.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import Function_Lib.ActionBot;
import org.openqa.selenium.support.ui.*;

import org.openqa.selenium.*;

import Obj_Lib.HomePage_obj;
import Obj_Lib.signupPage_Obj;

import java.io.BufferedWriter;		
import java.io.File;		
import java.io.FileWriter;

import org.testng.annotations.Parameters;

public class SignUp extends Init {
	
	static WebElement email_id_textbox = null;
	static WebElement dropdown = null;
	static boolean flag = false;
	static String [] Country = {"India","United Kingdom","South Africa"};
	static String emailid = null,country = null;
	
    @Test
	public static void Fn_Signup() throws Exception
     
     {
    	 try{
    		 
    		 ActionBot.Fn_click(HomePage_obj.signup_button());
    		 Thread.sleep(3000);
    		// System.out.println("Sign Up  Clicked");
    		 app_logs.info("Sign Up is Successful");
    		 
    	     
    	 }
    	 
    	 catch(Exception e)
    	 {
    		 Assert.fail();
    	 }
    	 
     }
     
    @Test
    @Parameters ({"emailid"})
     public static void Fn_emailid(String email_id) throws Exception
     
     {
    	
    	 try 
    	 {
    		 emailid = email_id;
    	 
    	 email_id_textbox = driver.findElement(signupPage_Obj.emailid_textbox());
    	 flag =  email_id_textbox.isEnabled();
    	 if (!flag)
    	 {
    	       System.out.println("Element is not enabled for ->"+ email_id_textbox);
    	     //softAssert
    	    }
    	 else if (flag)
    	 {
    		 email_id_textbox.sendKeys(email_id);
    		 app_logs.info("Email id is entered");
    	 }
    	 }
    	 catch (Exception e)
    	 {
    		 Assert.fail("Email id is not visible");
    	 } 
     }
	
    @Test
    @Parameters ({"country"})
    public static void Fn_dropdown_Country(String drpDown_cntry) throws Exception
     
     {
    	try 
    	 {
    	    country = drpDown_cntry;
    	    dropdown = driver.findElement(signupPage_Obj.country_dropdwn());
    	    Select select = new Select(dropdown);
    	    
    	    List<WebElement> resultset = select.getOptions();
    	     
    	    for (WebElement CntryList : resultset)  { 
    	       for (int i = 0; i<Country.length;i++)
    	         {
    	    	   if (CntryList.getText().equalsIgnoreCase(Country[i]))
    	    	   {
    	    		   app_logs.info("Country list matches");
    	    		   select.selectByValue(drpDown_cntry);
    	    		   Thread.sleep(3000);
    	    		   
    	    	   }
    	    	   else
    	    	   {
    	    		   app_logs.info("Country list does not match");
    	    	   }
    	    	  
    	          }  
    	    }
    	 
    	 }
    	 catch (Exception e)
    	 {
    		Assert.fail();
    	 } 
     }
    
    @Test
    public static void Fn_get_started() throws Exception
    {
    	
    	try {
    		
    		flag = ActionBot.Fn_Enabled(signupPage_Obj.getstarted_button());
    		app_logs.info("Sign Up is enabled");
    		ActionBot.Fn_click(signupPage_Obj.getstarted_button());
    		app_logs.info("Sign Up - Step 1 completed"); 
    		
    		File file = new File("Cookies.data");
    		// Delete old file if exists
    					file.delete();		
    		            file.createNewFile();			
    		            FileWriter fileWrite = new FileWriter(file);							
    		            BufferedWriter Bwrite = new BufferedWriter(fileWrite);							
    		            // loop for getting the cookie information 		
    		            	
    		            // loop for getting the cookie information 		
    		            for(Cookie ck : driver.manage().getCookies())							
    		            {			
    		                Bwrite.write((ck.getName()+";"+ck.getValue()+";"+ck.getDomain()+";"+ck.getPath()+";"+ck.getExpiry()+";"+ck.isSecure()));																									
    		                Bwrite.newLine();             
    		            }			
    		            Bwrite.close();			
    		            fileWrite.close();
    		driver.close();

    	}
    	catch(Exception e)
    	{
    	  Assert.fail();
    	  e.printStackTrace();
    	}
    }
}
