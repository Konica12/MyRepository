package Function_Lib;


import org.apache.log4j.Logger;

import org.openqa.selenium.By;

import org.testng.Assert;

import clearscore.Init;

public class ActionBot extends Init {
	
	static Logger app_logs= Logger.getLogger(Init.class);

	public static void Fn_click (By by_element) throws Exception{
		

		try{
	

			driver.findElement(by_element).click();

			//Logger to log function name and status
			app_logs.info(new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->pass");
			//test.log(LogStatus.PASS,new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->pass");

		}catch(Exception e){

			app_logs.info(new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->exception");

			//cu.FnTestCaseStatusReport("FAIL",new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->Object Not found");

			//test.log(LogStatus.FAIL,new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->Object Not found");			

			//cu.FnTestCaseStatusReport("FAIL", new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->Object Not found");
			e.printStackTrace();

			//Assert.fail() to report in TestNG report
			Assert.fail();
			//############ End of Common lines for each function-> Catch to report the exception with function name	##########
		}
	}
		
		public static Boolean Fn_Enabled (By by_element){


			//Function variables
			Boolean exists=false;

			try{

				boolean disable = driver.findElement(by_element).isEnabled();

				if((disable)) {
					exists=true;
					//test.log(LogStatus.PASS,elename+ " is enabled in the UI as expected");

				}
				else {

					//test.log(LogStatus.WARNING,elename+ " is disabled in the UI");
				}

				app_logs.info(new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->pass");


			}catch(Exception e){


				app_logs.info(new Object (){}.getClass().getEnclosingMethod().getName() + "->" + by_element + "->exception");

			}

			return exists;

		}
}
